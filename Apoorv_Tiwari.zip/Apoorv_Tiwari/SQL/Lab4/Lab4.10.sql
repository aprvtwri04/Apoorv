TRUNCATE table cust_table;
