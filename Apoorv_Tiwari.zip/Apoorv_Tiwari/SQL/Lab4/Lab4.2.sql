Alter table customer rename column cust_name to customername;
Alter table customer modify customername  varchar2(30) Not Null;