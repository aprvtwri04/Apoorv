CREATE INDEX no_name on emp(empno);
select * from emp;