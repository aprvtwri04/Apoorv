CREATE sequence SEQ_EMP minvalue 1001 start with 1001
	increment by 1 cache 1001; 