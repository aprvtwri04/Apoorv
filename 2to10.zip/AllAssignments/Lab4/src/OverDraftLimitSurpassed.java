public class OverDraftLimitSurpassed extends Exception
{
	public OverDraftLimitSurpassed()
	{
		System.out.println("OverDraft Limit Crossed!");
	}

}