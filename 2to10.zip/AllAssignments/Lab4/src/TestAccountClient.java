public class TestAccountClient 
{

	public static void main(String[] args) 
	{
		
		double acNo1 = Math.random()*1000;
		double acNo2 = Math.random()*1000;
		
		Person p1 = new Person();
		p1.setName("Smith");
		p1.setAge(22);
		Account Smith = new Account();
		Smith.setAccNum((long) acNo1);
		Smith.setBalance(2000);
		Smith.setAccHolder(p1);
		
		Person p2 = new Person();
		p2.setName("Kathy");
		p2.setAge(21);
		Account Kathy = new Account();
		Kathy.setAccNum((long) acNo2);
		Kathy.setBalance(3000);
		Kathy.setAccHolder(p2);

		
		
		Smith.deposit(2000);
		//System.out.println("Smith's Balance : " + Smith.getBalance());
		System.out.println(p1);
		System.out.println(Smith);
		
		//Kathy.withdraw(2000);
		//System.out.println("Kathy's Balance : " + Kathy.getBalance());
		try
		{
			Kathy.withdraw(2000);
		}
		catch(BalanceNotSufficientException e)
		{
			e.printStackTrace();
		} catch (OverDraftLimitSurpassed e) 
		{
			
			e.printStackTrace();
		}
		System.out.println(p2);
		System.out.println(Kathy);
		
		

	}

}