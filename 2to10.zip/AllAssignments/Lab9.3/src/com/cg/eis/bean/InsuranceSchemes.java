package com.cg.eis.bean;
public enum InsuranceSchemes
{
	SchemeA,SchemeB,SchemeC,NoSchemes
}