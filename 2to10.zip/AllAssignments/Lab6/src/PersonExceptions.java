
public class PersonExceptions {
	//Implemented in assignment Lab2 com.cg.person package
}
