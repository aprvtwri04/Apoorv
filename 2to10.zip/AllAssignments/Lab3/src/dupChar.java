//else if(choice==3)
//		{
//			
//			char strArr[]=str.toCharArray();
//			for (int i = 0; i < strArr.length; i++) 
//			{
//				for (int j = 1; j < strArr.length;j++) 
//				{
//					if(strArr[i]==strArr[j])
//					{
//						strArr[i]=strArr[j];
//						
//					}
//				}
//			}
//			String s=String.valueOf(strArr);
//			System.out.println(str);	
//		}