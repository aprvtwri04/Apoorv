import java.util.Scanner;

public class PositiveString
{
	public boolean posStr(String str)
	{
		int count=0;
		boolean temp;
		char ar[]=str.toCharArray();
		for (int i = 0; i < ar.length; i++) 
		{
			for (int j = i+1; j < ar.length; j++)
			{
				if(ar[i]>ar[j])
				{
					count++;
					break;
				}
			}
		}
		if(count==0)
		{
			temp=true;
		}
		else
		{
			temp=false;
		}
		
		return temp;
	}
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter String: ");
		String input=sc.next();
		
		PositiveString obj=new PositiveString();
		System.out.println(obj.posStr(input));
	}
}