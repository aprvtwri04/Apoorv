import java.util.Arrays;
import java.util.Scanner;


 class SortArrayObject{
	public String sort(String str,int size)
	{
		char arr[]=str.toCharArray();
		Arrays.sort(arr);
		return Arrays.toString(arr);
		
	}
	}
public class ArrayOfString {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number of Strings: ");
		int size=sc.nextInt();
		String[] str=new String[size];
		System.out.println("Enter desired Strings: ");
		for (int i = 0; i < size; i++) {
			str[i]= sc.next();	
		}
		String str1=str.toString();
		System.out.println(str1);
		SortArrayObject obj=new SortArrayObject();
		System.out.println(obj.sort(str1, size));	
	}
}
