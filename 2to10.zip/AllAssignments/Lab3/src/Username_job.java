import java.util.Scanner;

class user
{
	public boolean UName(String str)
	{
		boolean temp;
		String _job="_job";
		
		if(str.length()>=8)
		{
		System.out.print("UserName= "+str+_job+"\n");
		temp=true;
		}
		else
		{
			temp=false;
		}
		
		return temp;
	}
	}

public class Username_job 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter UserName: ");
		String input=sc.next();
		
		user obj=new user();
		System.out.println(obj.UName(input));
	}
}
