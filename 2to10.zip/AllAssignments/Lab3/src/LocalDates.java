import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;


public class LocalDates {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Day: ");
		int day1=sc.nextInt();
		System.out.println("Enter Month: ");
		int month1=sc.nextInt();
		System.out.println("Enter Year: ");
		int year1=sc.nextInt();
		LocalDate firstDate=LocalDate.of(year1, month1, day1);
		
		System.out.println("Enter another Day: ");
		int day2=sc.nextInt();
		System.out.println("Enter another Month: ");
		int month2=sc.nextInt();
		System.out.println("Enter another Year: ");
		int year2=sc.nextInt();
		LocalDate secondDate=LocalDate.of(year2, month2, day2);
		
		Period duration=Period.between(firstDate, secondDate);
		
		System.out.println("Duration between two dates is "+duration.getDays()+" Day/s "+duration.getMonths()+" Month/s "+duration.getYears()+" Year/s");
	}
}
