import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.Scanner;

public class DurationFromCurrentDate {

	public static void main(String[] args) {
		
		LocalDate now=LocalDate.now();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Day: ");
		int day=sc.nextInt();
		System.out.println("Enter Month: ");
		int month=sc.nextInt();
		System.out.println("Enter Year: ");
		int year=sc.nextInt();
		LocalDate newDate=LocalDate.of(year, month, day);
		Period duration=Period.between(newDate,now);
		System.out.println("Difference is: "+duration.getDays()+" Day/s "+duration.getMonths()+" Month/s "+duration.getYears()+" Year/s ");
		
		
	}
}
