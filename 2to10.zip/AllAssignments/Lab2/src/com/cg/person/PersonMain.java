package com.cg.person;

import java.util.Scanner;

import com.cg.person.AgeLimitException;
import com.cg.person.InvalidNameException;
public class PersonMain {
	public static void main(String[] aa) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your First Name : ");
		String firstName= scanner.nextLine();
		System.out.println("Enter your Last Name : ");
		String lastName= scanner.nextLine();
		if(firstName.length()<=0 ||lastName.length()<=0)
			try {
				throw new InvalidNameException("Name should contains Some Characters.");
			} catch (InvalidNameException e) {
				e.printStackTrace();
			}
		System.out.println("Enter your Gender : ");
		String gender= scanner.next();
		System.out.println("Enter your age : ");
		int age= scanner.nextInt();
		try {
			throw new AgeLimitException("Age  limit to be above 15  ");
		} catch (AgeLimitException e) {
			e.printStackTrace();
		}
		System.out.println("Enter your weight : ");
		double weight = scanner.nextDouble();
		Person person = gender.equals("M")?new Person(firstName, lastName, Gender.M, age, weight):gender.equals("F")?new Person(firstName, lastName, Gender.F, age, weight):new Person();
		if(person == null)
			try {
				throw new InvalidNameException("Only males and females are allowed. ");
			} catch (InvalidNameException e) {
				e.printStackTrace();
			}
		System.out.println("First name : "+person.getFirstName()+"\nLast Name : "+person.getLastName()+"\nGender : "+person.getGender()+"\nAge : "+person.getAge()+"\nWeight : "+person.getWeight());
	}
}
