package com.cg.person;

public class DisplayDetails {

	public static void main(String[] args) 
	{
		String firstName="Divya",lastName="Bharathi";
		Character gender='F';
		int age=20;
		float weight=85.55f;
		
		System.out.println("Person Details: "+"\n_________\n\nFirst Name: "+firstName+
				"\nLast Name: "+lastName+"\nGender: "+gender+"\nAge: "+age+"\nWeight: "+weight);

	}

}
